# Custom Login Page

Plugin for Umbraco 7.4.3+

This is a tweak for the login page, changing the visual of the layout. It adds a custom css and javascript injections into the Login page.

It also adds a "loading" after clicking login, and it changes the background image for the screen.

To customize it, you should open ~/App_Plugins/Custom.Login.Page/css/style.css and change the style to fit your needs.

